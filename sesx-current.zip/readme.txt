INSTALLATION INSTRUCTIONS:

1)  Create a folder called FiveM
2)  Download FiveM artifacts for your OS and place in a folder called artifacts inside the FiveM folder.
3)  Place the server-data folder found in this archive inside the FiveM folder.
4)  Open FiveM/server-data/server.cfg in a text editor.
5)  Visit https://steamcommunity.com/dev/apikey and generate a web API key.  Insert that key where instructed in server.cfg.
6)  Insert your MySQL database name, username and password where instructed in server.cfg.
7)  Replace the SteamID with your own around line 19 for ES admin privileges.
8)  Visit https://keymaster.fivem.net to generate a server key and add that at the bottom of the server.cfg.
9)  Save server.cfg
10) Import sesx.sql into your MySQL database.
11) Start the server.  How you do this depends on your OS. Check Schwim's how-to videos for help. https://www.youtube.com/channel/UCkG-_q2COKp6X5XlxVROW7Q/videos
12) Enjoy your game!