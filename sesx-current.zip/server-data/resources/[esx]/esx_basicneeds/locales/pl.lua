Locales['pl'] = {
  ['used_bread'] = 'zjadłeś/aś ~y~1x~s~ ~b~chleb~s~',
  ['used_water'] = 'wypiłeś/aś ~y~1x~s~ ~b~woda~s~',
}