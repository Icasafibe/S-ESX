Locales['de'] = {
  ['used_bread'] = 'du hast ~y~1x~s~ ~b~Brot gegessen~s~',
  ['used_water'] = 'du hast ~y~1x~s~ ~b~Wasser getrunken~s~',
}