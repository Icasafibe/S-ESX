USE `essentialmode`;

INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('bread', 'Brot', 10),
	('water', 'Wasser', 5)
;