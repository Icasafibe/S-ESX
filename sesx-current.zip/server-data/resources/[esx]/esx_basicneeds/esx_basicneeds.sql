USE `essentialmode`;

INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('bread', 'Pain', 10),
	('water', 'Eau', 5)
;